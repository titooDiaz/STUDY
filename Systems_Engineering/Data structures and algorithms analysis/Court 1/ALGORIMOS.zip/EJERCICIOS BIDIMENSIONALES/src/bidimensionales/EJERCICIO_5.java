package bidimensionales;

public class EJERCICIO_5 {
    // En las Unidades Tecnológicas de Santander se conoce el número de alumnos que ingresaron en
    //sus 7 diferentes carreras, en los últimos 12 años. Construya un diagrama de flujo que pueda
    //proporcionar la siguiente información:
    //a. Total de alumnos por año
    //b. Porcentaje de alumnos ingresados en el año 7 en la carrera 2, respecto al total de ese año
    //c. En que año y en qué carrera se dio el menor ingreso de alumnos
    //d. Año en el cual la carrera 4 tuvo el mayor ingreso de alumnos
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
