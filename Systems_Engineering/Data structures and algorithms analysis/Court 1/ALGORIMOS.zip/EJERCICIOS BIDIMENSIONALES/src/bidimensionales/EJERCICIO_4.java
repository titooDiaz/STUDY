package bidimensionales;
public class EJERCICIO_4 {
    // Construya un diagrama de flujo que permita calcular la tabla de multiplicar del 1 al 10. Imprima
    // al final el resultado en forma de tabla
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
