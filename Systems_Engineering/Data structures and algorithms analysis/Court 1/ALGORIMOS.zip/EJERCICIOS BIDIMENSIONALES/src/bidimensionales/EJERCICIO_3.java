package bidimensionales;

import java.util.Scanner;

public class EJERCICIO_3 {
    // Se tiene la información de un grupo de estudiantes universitarios de los cuales se conocen sus
    // tres notas. La información se ingresa en forma de tabla donde cada fila representa al estudiante
    //y cada columna una de las notas, Desarrolle un programa que permita calcular lo siguiente:
    //a. El promedio de las calificaciones de los tres cortes
    //b. El promedio de cada alumno
    //c. El examen que tuvo el mayor promedio y escriba dicho promedio
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("ESCRIBE LA CANTIDAD DE ESTUDIANTES QUE QUIERES ESTUDIAR: ");
        int number = input.nextInt();
        int[][] notas = new int[number][3];
        float[] average = new float[5];
        float[] best = new float[2];
        float[] averageStudent = new float[number];
        String[] names = new String[number];
        System.out.println("RELLENE LOS DATOS DE LOS ESTUDIANTES: ");
        for (int i =0; i<number; i++){
            System.out.print("-- COLOQUE LAS NOTAS DEL ESTUDIANTE: "+ (i+1) +": \n nombre: ");
            System.out.print("");
            names[i] = input.next();
            for (int j = 0; j <3; j++){
                System.out.println("nota "+j+": ");
                notas[i][j] = input.nextInt();
                average[j] = average[j] + notas[i][j];
                averageStudent[i] = averageStudent[i] + notas[i][j];
            }
            averageStudent[i] = (float) (averageStudent[i]/3.0);
            if (averageStudent[i]>best[1]){
                best[1] =(averageStudent[i]);
                best[0]=i+1;
            };
        }
        System.out.println("\n| nombre | nota 1 | nota 2 | nota 3 | promedio");
        for (int i =0; i<number; i++){
            if ((best[0]-1)==i){System.out.println("|  *"+names[i]+ "*  |  "+ notas[i][0]+ "   |  "+ notas[i][1] + "   |  " +  notas[i][2] + "   |  "+ averageStudent[i]);}else{System.out.println("|  "+names[i]+ "  |  "+ notas[i][0]+ "   |  "+ notas[i][1] + "   |  " +  notas[i][2] + "   |  "+ averageStudent[i]);}
        }
        System.out.println("-----------------------------");
        System.out.println("| total |   " + average[0]/number + " |  " + average[1]/number + "  |  " + average[2]/number +" | ");
        System.out.println("\nEl estudiante con mayor nota fue "+ names[(int) best[0]-1] + " Con promedio " + best[1]);
    }
    
}
