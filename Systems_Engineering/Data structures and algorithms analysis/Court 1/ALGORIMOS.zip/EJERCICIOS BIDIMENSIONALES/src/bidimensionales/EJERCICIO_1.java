package bidimensionales;

import java.util.Arrays;

public class EJERCICIO_1 {
//    1. Se tienen dos arreglos bidimensionales A (m X n) y B (m X n)realice un programa que calcule la
//    suma de los arreglos A y B y almacene su nuevo resultado en el arreglo C (m x n
    public static void main(String[] args) {
        int m = 4;
        int n = 3;
        int[][] A = new int[m][n];
        int[][] B = new int[m][n];
        int[][] C = new int[m][n];
        
        
        for (int i =0 ; i < m ; i++){
            for (int j =0 ; j < n ; j++){
                A[i][j] = (int) (Math.random() * 100);
                B[i][j] = (int) (Math.random() * 100);
                C[i][j] = A[i][j] + B[i][j];
            }
        }
        
        // mostrar todo
        System.out.println("matriz A:");
        for (int i =0 ; i < m ; i++){
            System.out.println(Arrays.toString(A[i]));
        }
        System.out.println("matriz B:");
        for (int i =0 ; i < m ; i++){
            System.out.println(Arrays.toString(B[i]));
        }
        
        System.out.println("MATRIZ SUMA:");
        for (int i =0 ; i < m ; i++){
            System.out.println(Arrays.toString(C[i]));
        }
    }
    
}
