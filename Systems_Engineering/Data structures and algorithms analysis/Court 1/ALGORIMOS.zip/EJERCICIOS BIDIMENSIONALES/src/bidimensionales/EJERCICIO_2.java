package bidimensionales;

import java.util.Arrays;

public class EJERCICIO_2 {
    //Escriba un programa para que al tener una matriz cuadrada sume los valores contenidos en su
    // diagonal principal
    public static void main(String[] args) {
        int m = 4;
        int[][] A = new int[m][m];
        
        // llenar la diagonal
        for (int i =0 ; i < m ; i++){
            A[i][i] = (int) (Math.random() * 100);
        }
        
        System.out.println("matriz A:");
        int sumatoria = 0;
        for (int i =0 ; i < m ; i++){
            System.out.println(Arrays.toString(A[i]));
            sumatoria = sumatoria + A[i][i];
        }
        
        System.out.println("LA SUMA DE NUMEROS ES: " + sumatoria);
    }
    
}
