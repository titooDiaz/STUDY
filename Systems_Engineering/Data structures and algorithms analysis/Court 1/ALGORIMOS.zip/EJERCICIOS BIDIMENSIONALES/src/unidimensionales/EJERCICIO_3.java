package unidimensionales;

import java.util.Arrays;

public class EJERCICIO_3 {
    //Construya un programa que almacene en un arreglo unidimensional los primeros 100 números
    // impares. Al final muestre el contenido de todo el vector
    public static void main(String[] args) {
        // primeros 100 numeros impares
        int[] I = new int[100];
        for (int i = 0; i<100;i ++){
            I[i] = 2*i + 1 ;
        }
        System.out.println("VECTOR:" + Arrays.toString(I));
    }
    
}
