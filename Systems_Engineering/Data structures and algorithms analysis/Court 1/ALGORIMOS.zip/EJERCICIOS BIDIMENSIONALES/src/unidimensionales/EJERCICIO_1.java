package unidimensionales;

import java.util.Arrays;

public class EJERCICIO_1 {
    //1. Dados dos vectores de tipo entero A y B, construya un programa que calcule el producto de cada
    // una de las posiciones de los vectores y ese resultado lo guarde en un nuevo vector C.
    public static void main(String[] args) {
        int number = 5;
        int[] A = new int[number];
        int[] B = new int[number];
        int[] C = new int[number];
        
        // rellenar vcampos con numeros aleatorios y mostrar las multiplcacaciones
        for (int i =0; i < A.length; i++){
            // rellenar el array en [0,99]
            A[i] = (int) (Math.random() * 100);
            B[i] = (int) (Math.random() * 100);
            
            // mostrar resultados
            C[i] = A[i] * B[i];
            System.out.println(A[i] + " * " + B[i] + " = " + A[i]*B[i]);
        }
        
        System.out.println("VECTOR A:" + Arrays.toString(A));
        System.out.println("VECTOR B:" + Arrays.toString(B));
        System.out.println("VECTOR C:" + Arrays.toString(C));
    }
    
}
