package unidimensionales;

import java.util.Scanner;

public class EJERCICIO_6 {
    // Supóngase que en una elección de alcaldes, se presentaron 10 candidatos (con identificadores
    // 1,2,3,...,10). Por otra parte, los votos para cada candidato se teclean de manera desorganizada
    // como se muestra a continuación: 1 5 7 5 1 10 10 7 1 7 5 8 1 5 – 1, es decir el usuario vota
    // escribiendo el número del candidato y así sucesivamente hasta que se cierren las votaciones. Al
    // final se deberá mostrar quien es el ganador, cuál es el total de votos del ganador, el porcentaje
    // de cada candidato respecto al total de votos
    public static void main(String[] args) {
       int[] votos = new int[10];
       Scanner input = new Scanner(System.in);
       int contador = 0;
       while (true){
           System.out.println("POR CUAL CANDIDADO DESEA VOTAR?: (1-10 para votar y -1 para acabar) VOTO NUMERO: "+(contador+1));
           
           int voto = input.nextInt();
           if (voto < 10 && voto > 0){
               contador = contador+1;
               votos[voto-1] ++;
           }else{
               System.out.println("Voto no valido. ");
           }
           if (voto == -1){
               System.out.println("FIN DE LA VOTACIONES!");
               break;
           }
       }
       
       int mayor = 0;
       for (int i = 0; i<10;i++){
           if (votos[i] > votos[mayor]){
               mayor = i;
           }
       }
        System.out.println("EL GANADOR FUE EL ALCALDE NUMERO: " + (mayor+1) + " CON " + votos[mayor] + " VOTOS.");
    }
    
}
