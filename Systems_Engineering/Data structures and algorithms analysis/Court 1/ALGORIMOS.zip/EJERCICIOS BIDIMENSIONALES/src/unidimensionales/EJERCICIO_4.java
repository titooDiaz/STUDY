package unidimensionales;

import java.util.Arrays;
import java.util.Scanner;

public class EJERCICIO_4 {
    // Diseñe un algoritmo que permita realizar en orden, las siguientes operaciones con vectores
    // Registrar en un vector A, 15 números enteros.
    // a. Cada valor almacenado en el vector A lo multiplica por un valor constante digitado por el
    // usuario y lo guarda en un vector B.
    // b. En un vector C, guarda el resultado de la resta del vector B menos el vector A.
    // c. Para finalizar muestra el contenido de los tres vectores A, B y C
    public static void main(String[] args) {
        int[] A = new int[15];
        int[] B = new int[15];
        int[] C = new int[15];
        Scanner input = new Scanner(System.in);
        int c = input.nextInt(); // constante para multiplicar al vector A
        System.out.println("\n ---------\n A --> A*c (B) \n ---------");
        for (int i = 0; i <15; i++){
            // paso 1
            A[i] = (int) (Math.random() * 100); // rellanr el vector a con numeros aleatorios
            B[i] = A[i]*c;
            System.out.println(A[i]+" --> " + B[i]);
            // paso 2
            C[i] = B[i] - A[i];
        }
        System.out.println("MOSTRAR TODOS LOS ARRAYS:\n VALORES DE A: "+ Arrays.toString(A) + "\n VALORES DE B: " + Arrays.toString(B) +"\n VALORES DE C: " + Arrays.toString(C));
        
    }
    
}
