package unidimensionales;
public class EJERCICIO_5 {
    // Diseñar un algoritmo que permita registrar en vectores el nombre y el peso en KG de cada jugador
    // del equipo de futbol de las UIS, al final calcular y mostrar el peso promedio de todos los jugadores,
    // cual es el más pesado (nombre y peso) y el menos pesado (nombre y peso)
    public static void main(String[] args) {
        String[] nombre={"jorge","miguel","cristian","felipe","juan"};
        int[] pesos={63,63,60,83,50};
        int[] indices = {0,0};
        // los primeros dos son menor y nombre, luego mayor y nombre
        int sumatoria = 0;
        
        for (int i=0;i<nombre.length;i++){
            sumatoria += pesos[i];
            if (pesos[i]<pesos[indices[0]]){
                indices[0] = i;
            }
            if (pesos[i]>pesos[indices[1]]){
                indices[1] = i;
            }
        }
        System.out.println("EL PROMEDIO ES:" + ((float) sumatoria/nombre.length));
        System.out.println("EL MAYOR FUE "+ nombre[indices[1]]+ " CON UN PESO DE: "+ pesos[indices[1]]);
        System.out.println("EL MENOR FUE "+ nombre[indices[0]]+ " CON UN PESO DE: "+ pesos[indices[0]]);
    }
    
}
