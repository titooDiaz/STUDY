package unidimensionales;

import java.util.Scanner;

public class EJERCICIO_2 {
    // Realice un programa que registre en un vector, la cantidad de productos vendidos cada día,
    // durante una semana. Al final muestre el total de productos vendidos en la semana y el promedio
    // de ventas diario.
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] sellers = new int[7]; 
        int total = 0;
        for (int i = 1 ; i<8 ; i++){
            System.out.println("PRODUCTOS VEENDIDOS EL DIA " +i);
            int howMany = input.nextInt();
            sellers[i-1] = howMany;
            total = total + howMany;
        }
        
        System.out.println("RESUMEN DE VENTAS:");
        System.out.println("| LUNES | MARTES | MIERCOLES | JUEVES | VIERNES | SABADO | DOMINGO |");
        for (int i = 0 ; i < 7 ; i++){
            System.out.print("|    "+ sellers[i] +"    ");
        }
        System.out.println("\n-------------- Total: "+total +" - PROMEDIO: " + (total/7));
    }
    
}
