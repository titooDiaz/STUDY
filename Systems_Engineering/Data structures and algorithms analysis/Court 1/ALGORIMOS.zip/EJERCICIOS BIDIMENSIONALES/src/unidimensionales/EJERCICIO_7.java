package unidimensionales;

import java.util.Arrays;
    // Construya un algoritmo para almacenar en un arreglo unidimensional los primeros 30 números
    // primos. Al final imprima el arreglo correspondiente.
public class EJERCICIO_7 {
    public static void main(String[] args) {
        int[] primos = new int[30];
        primos[0]=2;
        int indice = 1;
        int n=3;
        while (indice <30){
            boolean prime = true;
            for (int i = 3; i <= Math.sqrt(n);i ++){
                if (n%i==0){
                    prime = false;
                    break;
                } 
            }
            if (prime){
                primos[indice]=n;
                indice++;
            }
            n=n+2;
        }
        System.out.println(Arrays.toString(primos));
    }
    
}
